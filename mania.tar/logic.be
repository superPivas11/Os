# logic.be - правила игры: появление нот, судейство попаданий,
# движение и рост сложности. Отрисовки тут нет.

# Сложность растёт ступенями: каждые ~7 секунд быстрее и чаще.
def bump_difficulty()
  if frames % 240 != 0   return  end

  speed = speed + 0.35
  if speed > 7.0   speed = 7.0   end

  spawn_every = spawn_every - 2
  if spawn_every < 8   spawn_every = 8   end
end

def spawn_note()
  var lane = math.rand() % LANES

  # Не даём двум нотам налезть друг на друга в одной дорожке -
  # иначе их физически не успеть нажать.
  for n : notes
    if n["lane"] == lane && n["y"] < NOTE_H * 2
      return
    end
  end
  notes.push({"lane": lane, "y": -NOTE_H})
end

def set_judge(text, color)
  judge_text  = text
  judge_color = color
  judge_left  = 12
end

# Нажатие по дорожке: ищем ближайшую к линии ноту именно в этой дорожке.
def hit_lane(lane)
  flash[lane] = 4

  var best  = -1
  var bestd = 9999

  var i = 0
  while i < size(notes)
    var n = notes[i]
    if n["lane"] == lane
      var d = n["y"] - HIT_Y
      if d < 0   d = -d   end
      if d < bestd
        bestd = d
        best  = i
      end
    end
    i = i + 1
  end

  if best < 0 || bestd > W_GOOD
    # Нажатие по пустой дорожке рвёт комбо, но игру не заканчивает.
    combo = 0
    set_judge("MISS", gfx.RED)
    return
  end

  notes.pop(best)
  combo = combo + 1
  if combo > max_combo   max_combo = combo   end

  # Множитель за комбо: каждые 10 нот подряд +10%, потолок x2.
  # Считаем в десятых долях, чтобы обойтись целыми числами.
  var mult = 10 + combo / 10
  if mult > 20   mult = 20   end

  if bestd <= W_PERFECT
    score = score + 300 * mult / 10
    set_judge("PERFECT", gfx.YELLOW)
  else
    score = score + 100 * mult / 10
    set_judge("GOOD", gfx.GREEN)
  end
end

# Двигает ноты вниз. false - нота улетела за экран, это проигрыш.
def update_notes()
  var i = 0
  while i < size(notes)
    var n = notes[i]
    n["y"] = n["y"] + speed
    if n["y"] > BOTTOM
      return false
    end
    i = i + 1
  end
  return true
end
