# draw.be - вся отрисовка. Логики игры тут нет, только рисование
# текущего состояния из config.be.
#
# gfx.flush() ни одна функция не вызывает - его зовёт тот, кто собрал
# кадр целиком. Иначе получилось бы несколько выгрузок на кадр и мерцание.

# Текст по центру экрана: 1 символ шрифта = 6 пикселей.
def text_center(y, s, color)
  var x = (gfx.W - size(s) * 6) / 2
  if x < 0   x = 0   end
  gfx.text(x, y, s, color, 1)
end

def draw_playfield()
  gfx.clear()

  # Разделители дорожек
  for i : 1 .. LANES - 1
    gfx.line(i * LANE_W, 0, i * LANE_W, BOTTOM, 0x2104)
  end

  # Подсветка нажатой дорожки, гаснет за 4 кадра
  for i : 0 .. LANES - 1
    if flash[i] > 0
      gfx.fillrect(i * LANE_W + 1, HIT_Y - 4, LANE_W - 2, NOTE_H + 8, 0x2145)
      flash[i] = flash[i] - 1
    end
  end

  # Линия попадания и приёмники
  gfx.fillrect(0, HIT_Y, gfx.W, 2, gfx.WHITE)
  for i : 0 .. LANES - 1
    gfx.rect(i * LANE_W + 6, HIT_Y - 3, LANE_W - 12, NOTE_H + 6, LANE_COLORS[i])
  end

  # Ноты
  for n : notes
    var y = n["y"]
    if y > -NOTE_H && y < BOTTOM
      gfx.fillrect(n["lane"] * LANE_W + 4, y, LANE_W - 8, NOTE_H,
                   LANE_COLORS[n["lane"]])
    end
  end

  # Счёт слева, комбо по центру
  gfx.text(2, 2, str(score), gfx.WHITE, 1)
  if combo > 1
    text_center(2, str(combo) + "x", gfx.YELLOW)
  end

  # Оценка последнего нажатия
  if judge_left > 0
    text_center(88, judge_text, judge_color)
    judge_left = judge_left - 1
  end
end

def draw_title()
  gfx.clear()
  text_center(20, "OSU MANIA", gfx.CYAN)
  gfx.line(30, 30, gfx.W - 30, 30, gfx.CYAN)
  text_center(42, "Lovi noty v takt", gfx.WHITE)

  # Раскладка клавиш прямо на дорожках
  for i : 0 .. LANES - 1
    gfx.rect(i * LANE_W + 6, 62, LANE_W - 12, 14, LANE_COLORS[i])
    gfx.text(i * LANE_W + LANE_W / 2 - 3, 65, LANE_LABELS[i], gfx.WHITE, 1)
  end

  var best = nvs.get("mania_best", 0)
  if best > 0
    text_center(86, "Rekord: " + str(best), gfx.YELLOW)
  end

  text_center(110, "ENTER start  ESC exit", gfx.GREEN)
  gfx.flush()
end

def draw_gameover(is_record)
  gfx.clear()
  text_center(14, "PROIGRAL", gfx.RED)
  gfx.line(30, 24, gfx.W - 30, 24, gfx.RED)

  gfx.text(14, 38, "Ochki:", gfx.WHITE, 1)
  gfx.text(86, 38, str(score), gfx.YELLOW, 1)

  gfx.text(14, 52, "Max combo:", gfx.WHITE, 1)
  gfx.text(86, 52, str(max_combo), gfx.CYAN, 1)

  gfx.text(14, 66, "Rekord:", gfx.WHITE, 1)
  gfx.text(86, 66, str(nvs.get("mania_best", 0)), gfx.GREEN, 1)

  if is_record
    text_center(84, "NOVYJ REKORD!", gfx.MAGENTA)
  end

  text_center(110, "ENTER snova  ESC exit", gfx.WHITE)
  gfx.flush()
end

# Отсчёт перед стартом, чтобы не терять первую ноту врасплох.
def draw_countdown(n)
  gfx.clear()
  for i : 0 .. LANES - 1
    gfx.rect(i * LANE_W + 6, HIT_Y - 3, LANE_W - 12, NOTE_H + 6, LANE_COLORS[i])
  end
  gfx.fillrect(0, HIT_Y, gfx.W, 2, gfx.WHITE)
  var s = str(n)
  var x = (gfx.W - size(s) * 6 * 4) / 2
  gfx.text(x, 50, s, gfx.YELLOW, 4)
  gfx.flush()
end
