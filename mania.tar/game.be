# game.be - игровой цикл. Загружается после config/logic/draw, поэтому их
# глобальные имена уже известны компилятору Berry.

def play_round()
  reset_game()

  for i : 0 .. 2
    draw_countdown(3 - i)
    delay(600)
  end
  input.flush()

  while alive
    var frame_start = millis()
    while true
      var e = input.key()
      if e == nil   break   end
      if e["key"] == input.ESC   return false   end

      var lane = key_to_lane(e["key"])
      if lane >= 0   hit_lane(lane)   end
    end

    if sys.aborted()   return false   end

    frames = frames + 1
    bump_difficulty()
    spawn_timer = spawn_timer - 1
    if spawn_timer <= 0
      spawn_note()
      spawn_timer = spawn_every
    end

    if !update_notes()
      alive = false
      break
    end

    draw_playfield()
    gfx.flush()
    var frame_time = millis() - frame_start
    if frame_time < 28   delay(28 - frame_time)   end
  end

  var is_record = false
  if score > nvs.get("mania_best", 0)
    nvs.set("mania_best", score)
    is_record = true
  end

  draw_gameover(is_record)
  input.flush()
  while true
    var e = input.wait(200)
    if sys.aborted()   return false   end
    if e == nil        continue       end
    if e["key"] == input.ENTER   return true   end
    if e["key"] == input.ESC     return false  end
  end
end

def mania_main()
  gfx.begin()
  input.begin()
  input.flush()

  init_config()
  draw_title()

  var playing = false
  while true
    var e = input.wait(200)
    if sys.aborted()   break   end
    if e == nil        continue end
    if e["key"] == input.ENTER   playing = true   break   end
    if e["key"] == input.ESC                      break   end
  end

  while playing
    playing = play_round()
  end

  input.close()
  gfx.close()
  print("Score:", score, "Max combo:", max_combo)
end

mania_main()
