# main.be - точка входа игры. Собирает модули и крутит главный цикл.
#
# Osu!mania на 4 клавиши: ноты падают сверху, лови их D F J K в момент,
# когда нота доходит до линии внизу. Пропустил - конец игры.
#
#   ENTER   старт / рестарт
#   ESC     выход
#   Ctrl+C  аварийный выход (обрабатывается системой)

import math

# Модули лежат рядом с main.be. Путь абсолютный: скрипт может быть
# запущен из любого каталога, относительные пути тут не сработают.
var HOME = "/lib/mania"

do_file(HOME + "/config.be")
do_file(HOME + "/logic.be")
do_file(HOME + "/draw.be")

# Одна партия. true - игрок хочет ещё раз, false - выходим.
def play_round()
  reset_game()

  for i : 0 .. 2
    draw_countdown(3 - i)
    delay(600)
  end
  input.flush()

  while alive
    # 1. Разгребаем ВСЮ очередь ввода. За кадр могло накопиться несколько
    #    нажатий, и терять их нельзя - это прямая потеря очков.
    while true
      var e = input.key()
      if e == nil   break   end

      if e["key"] == input.ESC
        return false
      end
      var lane = key_to_lane(e["key"])
      if lane >= 0
        hit_lane(lane)
      end
    end

    if sys.aborted()   return false   end

    # 2. Логика
    frames = frames + 1
    bump_difficulty()

    spawn_timer = spawn_timer - 1
    if spawn_timer <= 0
      spawn_note()
      spawn_timer = spawn_every
    end

    if !update_notes()
      alive = false
      break
    end

    # 3. Кадр целиком, потом одна выгрузка на экран
    draw_playfield()
    gfx.flush()
    delay(28)
  end

  var is_record = false
  if score > nvs.get("mania_best", 0)
    nvs.set("mania_best", score)
    is_record = true
  end

  draw_gameover(is_record)
  input.flush()

  while true
    var e = input.wait(200)
    if sys.aborted()   return false   end
    if e == nil        continue       end
    if e["key"] == input.ENTER   return true   end
    if e["key"] == input.ESC     return false  end
  end
end

def main()
  gfx.begin()
  input.begin()
  input.flush()

  init_config()
  draw_title()

  var playing = false
  while true
    var e = input.wait(200)
    if sys.aborted()   break   end
    if e == nil        continue end
    if e["key"] == input.ENTER   playing = true   break   end
    if e["key"] == input.ESC                      break   end
  end

  while playing
    playing = play_round()
  end

  input.close()
  gfx.close()

  print("Score:", score, "Max combo:", max_combo)
end

main()
