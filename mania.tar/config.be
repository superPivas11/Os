# config.be - константы игры и глобальное состояние.
#
# Первый файл, который грузит main.be. Всё, что тут объявлено через var
# на верхнем уровне, становится настоящим глобалом - остальные модули
# видят эти имена и могут их менять.

import math

# --- Геометрия под экран 160x128 ---
var LANES   = 4
var LANE_W  = 40           # 160 / 4
var HIT_Y   = 104          # линия, по которой судим попадание
var NOTE_H  = 7
var BOTTOM  = 128

# Окна попадания в пикселях от линии
var W_PERFECT = 6
var W_GOOD    = 14

# HID-коды клавиш D F J K.
# Берём коды, а не символы: тогда игра одинаково работает в русской
# раскладке, где на этих клавишах в ф о л.
var KEY_D = 0x07
var KEY_F = 0x09
var KEY_J = 0x0D
var KEY_K = 0x0E

var LANE_COLORS = []
var LANE_LABELS = ["D", "F", "J", "K"]

# --- Состояние партии ---
var notes       = []       # список map {lane, y}
var score       = 0
var combo       = 0
var max_combo   = 0
var speed       = 0.0      # пикселей за кадр
var spawn_every = 0        # кадров между появлением нот
var spawn_timer = 0
var frames      = 0
var alive       = true

var judge_text  = ""       # PERFECT / GOOD / MISS
var judge_color = 0
var judge_left  = 0        # сколько кадров ещё показывать
var flash       = [0, 0, 0, 0]   # подсветка дорожки при нажатии

def init_config()
  # Цвета задаём тут, а не в объявлении: gfx.* доступны только в рантайме
  LANE_COLORS = [gfx.CYAN, gfx.WHITE, gfx.WHITE, gfx.CYAN]
  math.srand(millis())
end

def reset_game()
  notes       = []
  score       = 0
  combo       = 0
  max_combo   = 0
  speed       = 1.8
  spawn_every = 26
  spawn_timer = 8
  frames      = 0
  alive       = true
  judge_text  = ""
  judge_left  = 0
  flash       = [0, 0, 0, 0]
end

def key_to_lane(code)
  if   code == KEY_D   return 0
  elif code == KEY_F   return 1
  elif code == KEY_J   return 2
  elif code == KEY_K   return 3
  end
  return -1
end
